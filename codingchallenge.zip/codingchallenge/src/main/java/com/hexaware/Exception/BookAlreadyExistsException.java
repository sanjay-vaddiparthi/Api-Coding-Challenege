package com.hexaware.Exception;

public class BookAlreadyExistsException extends Exception{
	public BookAlreadyExistsException(String msg) {
		super(msg);
	}

}
